=== Plugin Name ===
Contributors: Desertsnowman, Shelob9
Donate link: https://CalderaWP.com
Tags:
Requires at least: 3.9
Tested up to: 4.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

License Manager for CalderaWP Plugins -- provides a simple UI for activating and deactivating all CalderaWP plugins.

Moves all CalderaWP plugin licensing into one admin page. Easier for you, easier for us:)

This plugin is required for activating and deactivating licenses. It also enables updates via the WordPress plugin updater. Disabling this plugin disables the plugin updater, but does not disable the plugins licensed with it.
